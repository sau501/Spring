package springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class ReController {
    @RequestMapping("/one")
    //Using redirect prefix
//    public String one(){
//        System.out.println("You are in one handler");
//        return "redirect:/enjoy";
//    }
    //Using redirect view
    public RedirectView one(){
        System.out.println("You are in one handler");
        RedirectView view=new RedirectView();
        view.setUrl("enjoy");
        return view;
    }
    @RequestMapping("/enjoy")
    public String enjoy(){
        System.out.println("You are in enjoy handler");
        return "contact";
    }

}

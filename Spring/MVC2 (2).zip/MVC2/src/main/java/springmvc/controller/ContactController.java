package springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import springmvc.model.User;

@Controller
public class ContactController {

    @ModelAttribute
    //this wilol be addeed before each methosd in this class
    public void all(Model m){
        m.addAttribute("Header","Learning Spring");
        m.addAttribute("desc","Coding is fun !");
    }
    @RequestMapping("/contact")
    public  String contact(){
        return "contact";
    }
    //@ModdelAttribute method used
    //withoput model attribute we had to fit each parameter into user like
    //user.setname(name) and then add user class as attribute
    // like model.addAttribute("user, user)
    //and in jsp will have to use ${user.name}
    //Using modelAttribute no need of requestparam and user.set steps and sending data
    //from controller to view
    @RequestMapping("/process")
    public String processForm(@ModelAttribute User user){

        System.out.println(user);
        return "process";
    }

}
/*
    //@RequestParam method used
    //withoput model attribute we had to fit each parameter into user like
    //user.setname(name)
    //and in jsp willhave to use ${user.name}
    //Using modelAttribute no need of requestparam and user.set steps
    @RequestMapping("/process")
    public String processForm(@RequestParam("name") String name,
                              @RequestParam("email") String email,
                              @RequestParam("password") String password,
                              Model m){
        System.out.println("Your mail is "+email);
        System.out.println("yor name is "+name);
        System.out.println("your password is "+password);

        m.addAttribute("name",name);
        m.addAttribute("email",email);
        m.addAttribute("password",password);
        return "process";
    }
*/
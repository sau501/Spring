package springmvc.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
    @RequestMapping("/home")
    public String home(Model model){
        model.addAttribute("name","Pushpa Kamble");
        model.addAttribute("id",1224);
        System.out.println(" You are in home controller");
        return"index";
    }
    @RequestMapping("/about")
    public String about(){
        System.out.println("You are in about controller");
        return "about";
    }
    @RequestMapping("/help")
    public ModelAndView help(){
        ModelAndView model=new ModelAndView();
        model.setViewName("help");
        model.addObject("name","Shiva");
        model.addObject("no",99);
        LocalDateTime now=LocalDateTime.now();
        model.addObject("time", now);
        System.out.println("You are in help controller");
        return model;
    }
    

}

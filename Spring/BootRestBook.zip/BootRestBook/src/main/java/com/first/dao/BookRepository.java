package com.first.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.first.models.Book;

@Service
public interface BookRepository extends CrudRepository<Book, Integer> {
    public Book findById(int id);
	
}

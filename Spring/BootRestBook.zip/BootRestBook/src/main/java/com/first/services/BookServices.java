package com.first.services;

import com.first.dao.BookRepository;
import com.first.models.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
@Service
public class BookServices {
    //database should be configured here
    //This is fake service

//    private static List<Book> list=new ArrayList<>();
//
//    static {
//        list.add(new Book(13,"Shiva","Amish"));
//        list.add(new Book(14,"Ravana","Anand Nilkantan"));
//        list.add(new Book(15,"Sita","Chandrakanta"));}
	
	@Autowired
	private BookRepository bookRepository;

    //get all books
    public List<Book> getAll(){
        List<Book> list = (List<Book>) bookRepository.findAll();
        return list;
    }
    //one book by id
    public Book getBookById(int id){
        Book book = null;
        try {
           // book = list.stream().filter(e -> e.getId() == id).findFirst().get();
            return bookRepository.findById(id);
        } catch (Exception e){
            e.printStackTrace();
        }
        return book;
    }
    //adding one book
    public Book addBook(Book b){
        //list.add(b);
        bookRepository.save(b);
        return b;
    }
    //deleting book by id
    public void deleteBook(int id){
//        Book book=list.stream().filter(e->e.getId()==id).findFirst().get();
//        list.remove(book);
//        return book;
        bookRepository.deleteById(id);
    }
    //updating book by given book andf id
    public  Book updateBook(Book book , int id){
//        Book book1=getBookById(id);
//        book1.setAuthor(book.getAuthor());
//        book1.setTitle(book.getTitle());
//        return book1;
        book.setId(id);
        bookRepository.save(book);
        return book;
    }
}
